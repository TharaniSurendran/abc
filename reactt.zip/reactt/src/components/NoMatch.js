import React from 'react'

export default function NoMatch() {
  return (
    <div>
        page not found
    </div>
  )
}
